/* Representative corrected/optimized firmware structure.
 * Designed for the Week 3 debugging exercise; hardware-specific drivers are abstracted.
 */
bool acquire_environment_data(EnvironmentData *d)
{
    float t, h;

    if (!read_temperature_humidity(&t, &h)) {
        d->valid_th = false;
        return false;
    }

    if (t < TEMP_MIN || t > TEMP_MAX || h < HUM_MIN || h > HUM_MAX) {
        d->valid_th = false;
        return false;
    }

    d->temperature = t;
    d->humidity = h;
    d->valid_th = true;
    return true;
}

void evaluate_alerts(const EnvironmentData *d)
{
    if (!d->valid_th) {
        set_sensor_error_indicator();
        buzzer_off();
        return;
    }

    if (d->temperature > TEMP_LIMIT || d->humidity > HUM_LIMIT)
        buzzer_on();
    else
        buzzer_off();
}

void update_display_if_changed(const EnvironmentData *d)
{
    if (!display_data_changed(d)) return;
    oled_clear_buffer();
    oled_write_environment(d);
    oled_write_status(wifi_state, alert_state);
    oled_send_buffer();
}

void service_wifi_state_machine(void)
{
    switch (wifi_state) {
        case WIFI_CONNECTED:
            service_pending_upload();
            break;
        case WIFI_DISCONNECTED:
            if (retry_timer_elapsed()) start_non_blocking_reconnect();
            break;
        case WIFI_CONNECTING:
            poll_connection_progress();
            break;
    }
}

void loop(void)
{
    uint32_t now = millis();

    if ((now - last_sample) >= SAMPLE_INTERVAL_MS) {
        last_sample = now;
        if (acquire_environment_data(&data)) {
            update_air_quality();
            update_light_level();
            evaluate_alerts(&data);
            update_display_if_changed(&data);
        }
    }

    if ((now - last_upload) >= UPLOAD_INTERVAL_MS) {
        last_upload = now;
        try_non_blocking_wifi_upload(&data);
    }

    service_wifi_state_machine();
}
