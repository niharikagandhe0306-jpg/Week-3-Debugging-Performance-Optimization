/* Representative initial firmware for Week 3 debugging exercise.
 * Intentional/common issues are included for analysis; not claimed as physical-board code.
 */
void loop(void)
{
    read_temperature_humidity(&temperature, &humidity);
    air_quality = analogRead(AIR_QUALITY_PIN);
    light_level = analogRead(LIGHT_PIN);

    display_all(temperature, humidity, air_quality, light_level);
    display_refresh();

    if (temperature > TEMP_LIMIT || humidity > HUM_LIMIT)
        buzzer_on();
    else
        buzzer_off();

    if (!wifi_connected()) {
        connect_wifi();                 // may block the monitoring path
    }

    delay(5000);                        // blocks other work
}
