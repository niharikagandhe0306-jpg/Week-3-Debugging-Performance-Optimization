# Week 3 – Debugging and Performance Optimization

**Intern:** Niharika Gandhe  
**Domain:** Embedded Systems / IoT  
**Project:** IoT-Based Smart Environment Monitoring System

## Objective
This repository supports Week 3 of the Embedded Systems Engineer Intern task. It documents a systematic debugging and performance-optimization exercise for an IoT smart environment monitoring firmware architecture.

## What is included
- `Report/` – detailed Week 3 technical report in Word format.
- `Code/initial_buggy_code.c` – representative firmware containing intentional/common debugging targets.
- `Code/optimized_firmware.c` – representative corrected and optimized firmware structure.
- `Evidence/` – supporting diagrams, logs and validation evidence.

## Debugging targets
1. Sensor return/status was not validated.
2. Invalid sensor values could propagate into display and alert logic.
3. OLED was refreshed unnecessarily.
4. Wi-Fi reconnection could block local monitoring.
5. Fixed delays reduced responsiveness and scheduling flexibility.

## Optimization approach
The corrected design uses explicit sensor validation, change-based display refresh, elapsed-time scheduling and a non-blocking Wi-Fi state machine. Functional correctness is considered before optimization.

## Validation
The report defines functional, negative, timing, Wi-Fi recovery, display and long-duration regression test cases. Representative performance comparisons are clearly identified as illustrative rather than physical-board measurements.

## Evidence note
Where physical hardware measurements were not available, logs and performance values are presented as representative/simulated evidence for the debugging exercise. They should not be interpreted as actual ESP32 laboratory measurements.
